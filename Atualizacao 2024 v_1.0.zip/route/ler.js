const express = require('express');
const router = express.Router();
const fuzz = require('fuzzball');
const fs = require('fs');
const rawData = fs.readFileSync('./assets/acf.json');
const bible = JSON.parse(rawData);

const chapterCounts = {};

// Itera sobre cada livro na Bíblia
bible.forEach(book => {
    const name = book.name;
    const abbrev = book.abbrev;
    const chapters = book.chapters;

    chapterCounts[abbrev] = chapters.length;

    console.log(`${name} (${abbrev}): ${chapters.length} capítulos`);
});

function encontrarLivroPorNome(nomeLivro) {
    // Encontrar o livro mais parecido usando matching fuzzy
    const opcoesLivros = bible.map(book => book.name);
    const resultadosFuzzy = fuzz.extract(nomeLivro, opcoesLivros, { scorer: fuzz.token_set_ratio });
    const livroMaisParecido = resultadosFuzzy[0][0];

    return bible.find(book => book.name === livroMaisParecido);
}

function obterVersiculo(livro, capitulo, versiculoInicio, versiculoFim) {
    const livroEncontrado = encontrarLivroPorNome(livro);

    if (!livroEncontrado) {
        return 'Livro não encontrado.';
    }

    const totalCapitulos = livroEncontrado.chapters.length;

    // Verifica se o número do capítulo está dentro dos limites do livro
    if (capitulo && capitulo > 0 && capitulo <= totalCapitulos) {
        const capitulos = livroEncontrado.chapters[capitulo - 1];
        
        // Converte versiculoInicio e versiculoFim para números
        versiculoInicio = parseInt(versiculoInicio);
        versiculoFim = parseInt(versiculoFim);

        // Verifica se os versículos de início e fim estão dentro dos limites do capítulo
        if (versiculoInicio && versiculoFim) {
            if (versiculoInicio >= 1 && versiculoFim <= capitulos.length && versiculoInicio <= versiculoFim) {
                return capitulos.slice(versiculoInicio - 1, versiculoFim);
            } else {
                return 'Versículo inicial ou final está fora do intervalo do capítulo.';
            }
        } else if (versiculoInicio) {
            if (versiculoInicio >= 1 && versiculoInicio <= capitulos.length) {
                if (!versiculoFim) {
                    return capitulos.slice(versiculoInicio - 1);
                } else {
                    return capitulos.slice(versiculoInicio - 1, versiculoFim);
                }
            } else {
                return 'Versículo inicial está fora do intervalo do capítulo.';
            }
        } else {
            return capitulos;
        }
    } else {
        return 'Capítulo não encontrado.';
    }
}


router.get('/:livro/:cap/:start?/:end?', async (req, res) => {
  const { livro, cap, start, end } = req.params;
  console.log(req.params);
  
  // Verifica se os parâmetros foram fornecidos
  if (!livro) {
    return res.status(400).send('O parâmetro do livro é obrigatório.');
  }

  // Chama a função para obter o versículo com base nos parâmetros fornecidos
  const resultado = obterVersiculo(livro, cap, start, end);

  // Retorna o resultado em formato JSON
  res.json({"Livro": livro, "Capítulo": cap || 'Não fornecido', "Versículo de início": start || 'Não fornecido', "Versículo de fim": end || 'Não fornecido', "Resultado": resultado});
});


module.exports = router;