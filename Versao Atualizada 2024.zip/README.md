# API BIBLIA JFA ATUALIZADA CORIGIDA FIEL
### required: express fuzzball fs router
# TODA HONRA  E GLORIA SEJA DADA A DEUS
  
#### Creditos https://github.com/thiagobodruk/bible

### use node .

### ex:  http://127.0.0.1:3000/ler/genesis/5/2/10
